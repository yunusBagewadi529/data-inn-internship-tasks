package com.internship.week4springbootcrudapp;

import lombok.Data;

@Data
public class DemoStudent {
    private Integer id;
    private String name;
    private String email;
    private int age;
}

