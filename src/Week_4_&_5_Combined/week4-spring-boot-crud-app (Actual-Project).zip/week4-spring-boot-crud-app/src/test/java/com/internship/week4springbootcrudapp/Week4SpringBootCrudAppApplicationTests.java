package com.internship.week4springbootcrudapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week4SpringBootCrudAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
