package com.intern.week5_sb_crud_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week5SbCrudBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
