package com.intern.week5_sb_crud_be;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week5SbCrudBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week5SbCrudBeApplication.class, args);
	}

}
